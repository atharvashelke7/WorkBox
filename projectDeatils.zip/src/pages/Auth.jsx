// import React, { Children, useEffect } from 'react'
// import { useNavigate } from 'react-router-dom'

// function Auth({Children}) {
// const navigate = useNavigate()
// const token  = localStorage.getItem("Jwttoken")
//      useEffect(()=>{
//         if(token === "") {
//           navigate("/")
//         }
//      },[token])

//   return Children
// }

// export default Auth
